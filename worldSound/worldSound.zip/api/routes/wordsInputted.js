const express = require('express');
const router = express.Router();
const fs = require('fs');



router.get('/words', (req, res, next) => {
	const data = fs.readFileSync("wordsFile.json");
	const info = JSON.parse(data);
	console.log(info)
	res.status(200).json(info);
});

router.post('/words', (req, res, next) => {


	const word = req.body.wordText;

	try {
	    const data = fs.readFileSync("wordsFile.json");
	    const info = JSON.parse(data);
	    info.push({word_inputted: word});
	    fs.writeFileSync("wordsFile.json", JSON.stringify(info));
	    res.status(200).json(info);
	} catch (err) {
	    console.log(err);
	    res.status(500);
	}

});



// router.delete('/', (req, res, next) => {
// 	res.status(200).json({
// 		messgae: 'Handling DELETE requests to /products'
// 	});
// });

module.exports = router;




